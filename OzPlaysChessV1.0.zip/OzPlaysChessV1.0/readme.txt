If the "images" folder is moved or renamed the game will no longer run.
I hope you enjoy it! :D