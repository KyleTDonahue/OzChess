This is version 0.1 of a project by Obcerd (@ObcerdArt on twitter)
There will be later updates with additional features and bugfixes.
If the "images" folder is moved or renamed the game will no longer run.
I hope you enjoy it! :D